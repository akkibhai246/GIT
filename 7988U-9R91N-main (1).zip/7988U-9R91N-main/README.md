# 𝙏𝘼𝘽𝘽𝙐 𝘼𝙍𝘼𝙄𝙉 😘😈

___𝙰𝙻𝙻 𝚃𝙷𝙴𝚂𝙴 𝚁𝙴𝙿𝙾𝚂𝙸𝚃𝙾𝚁𝙸𝙴𝚂 𝙰𝚁𝙴 𝙵𝚁𝙴𝙴 𝙵𝙾𝚁 𝙴𝚅𝙴𝚁𝚈𝙾𝙽𝙴 𝚃𝙾 𝙵𝙾𝚁𝙺 𝙰𝙽𝙳 𝙲𝚄𝚂𝚃𝙾𝙼𝙸𝚉𝙴 𝙰𝙲𝙲𝙾𝚁𝙳𝙸𝙽𝙶 𝚃𝙾 𝙾𝙽𝙴'𝚂 𝚃𝙰𝚂𝚃𝙴___</br>


 ### 𝕋𝟛ℝ𝟛 ℝ𝟡𝕋𝟘 𝕂𝟙 ℕ𝟛ℕ𝔻 𝔹𝟡ℝ𝔹𝟡𝔻 𝕂ℝℕ𝟡 𝕎𝟡𝕃𝟡 𝕊ℍ𝟡𝟙𝕋𝟡ℕ ℍ𝕌 𝕄𝟡 😈 
````bash
[[ 𝙏'𝙃-3-)) ❤ 𝙐 𝙉 𝙎 𝙏 0 𝙋 9 𝘽 𝙇 3 (𝙔) 𝙈 𝘼 𝙑 3 𝙍 1 𝘾 𝙆 (𝙔) #_______𝙏9𝘽𝘽𝙐__𝙆𝙄𝙉𝙂___0𝙉𝙁𝙄𝙄𝙍3 ________ (𝙔) 😎 {•------»:𝘿 ]]
````

# Screenshot 📷💾
<img src="https://github.com/Tabbu-Arain/Tabbu-king/blob/main/WhatsApp%20Image%202025-03-15%20at%2022.29.08_e5af55a6.jpg" />


<h3 align="left">𝘾𝙤𝙣𝙣𝙚𝙘𝙩 𝙒𝙞𝙩𝙝 𝙈𝙚</h3>

[![](https://img.shields.io/badge/Github-black?logo=Github&logoColor=black&labelColor=white)](https://github.com/Tabbu-Arain)

[![](https://img.shields.io/badge/Facebook-blue?logo=Facebook&logoColor=blue&labelColor=white)](https://www.facebook.com/TabbuArain)
[![](https://img.shields.io/badge/Whatsapp-CHAT-red?logo=Whatsapp&logoColor=Brightgreen&labelColor=white)](https://wa.me/994402197773?text=Hello+MR+Tabbu+)
